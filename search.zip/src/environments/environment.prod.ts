export const environment = {
  production: false,
  apiUrl: 'https://api.github.com/users/',
  apikey: '?access_token=1e09e1baa573d7f49014ffe3db068ea7ce8475cd',
  apiRepokey: '/repos?order=created&sort=asc?access_token=1e09e1baa573d7f49014ffe3db068ea7ce8475cd',
  apiLink: 'https://api.github.com/search/repositories?q=',
  apiRepos: '&per_page=101e09e1baa573d7f49014ffe3db068ea7ce8475cd'
};
