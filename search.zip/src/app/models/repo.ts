export class Repo {
  constructor(public name: string, public description: string, public html_url: string, public  clone_url: string, public homepage:string ) {}
}
