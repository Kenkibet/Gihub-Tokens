export class Searching {
  constructor(public name: string) {}
}
