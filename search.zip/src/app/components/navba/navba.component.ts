import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navba',
  templateUrl: './navba.component.html',
  styles: [
  ]
})
export class NavbaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
